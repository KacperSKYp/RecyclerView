package com.example.myapplication;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Country> countryList;
    CountryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.country_list_view);

        countryList = new ArrayList<>();
        countryList.add(new Country("Polska"));
        countryList.add(new Country("Niemcy"));
        countryList.add(new Country("Francja"));
        countryList.add(new Country("Włochy"));
        countryList.add(new Country("Hiszpania"));
        countryList.add(new Country("Norwegia"));
        countryList.add(new Country("Szwecja"));
        countryList.add(new Country("Japonia"));
        countryList.add(new Country("Kanada"));
        countryList.add(new Country("Brazylia"));

        adapter = new CountryAdapter(this, countryList);
        listView.setAdapter(adapter);
    }
}
